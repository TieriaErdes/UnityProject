# Unity simple Pick Up system
 How to create a pick up and interaction system in Unity 3d
